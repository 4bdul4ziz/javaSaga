//same as menuBased but without objects


public class menuBasedObject {


}
