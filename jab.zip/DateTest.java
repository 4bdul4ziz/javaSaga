public class DateTest {
    public static void main(String[] args) {
        Date date = new Date(1, 1, 2020);
        date.displayDate();
    }
    
}
