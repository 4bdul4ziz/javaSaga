//todo number methods
public class numberMethods {
    
}
