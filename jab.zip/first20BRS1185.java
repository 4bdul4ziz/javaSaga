
    class First {
        int data = 40;

        void msg() {
            System.out.println("Hello java");
        }

    }

    public class first20BRS1185 {
        public static void main(String args[]) {
            First obj = new First();
            System.out.println(obj.data);
            obj.msg();
        }
    }

